# CT Credentials Tracker

Sends daily email reminders for ARRT, State License, and BLS credential expirations via GitHub Actions.

## Setup (3 steps)

### 1. Create a GitHub repo and upload these files
- Go to github.com → New repository (name it anything, e.g. `ct-credentials`)
- Upload all these files keeping the folder structure intact
- Or use git: `git init`, `git add .`, `git commit -m "init"`, `git push`

### 2. Add your Outlook credentials as GitHub Secrets
In your repo: **Settings → Secrets and variables → Actions → New repository secret**

| Secret name | Value |
|---|---|
| `OUTLOOK_USER` | The Atrius email to send FROM |
| `OUTLOOK_PASSWORD` | That account's Outlook password |

> If Atrius IT has MFA on the mailbox, ask them for an **App Password** or to enable **SMTP AUTH** for that account.

### 3. Enable Actions and you're done
Go to the **Actions** tab in your repo and confirm Actions are enabled.
The job runs automatically every day at **7:00 AM Eastern**.

---

## Updating a credential date
1. Open `scripts/send-reminders.js`
2. Find the tech in the `TECHS` array
3. Update the date (`YYYY-MM-DD` format)
4. Commit and push — done

## Running manually
Go to **Actions → CT Credential Reminders → Run workflow** to trigger it immediately.
Check the run logs to see exactly which emails were sent.

## Email schedule
| Trigger | Recipients |
|---|---|
| 30 days before expiration | Tech + Raghda (supervisor) + Cheryl (manager) |
| 14 days before expiration | Tech + Raghda + Cheryl |
| 7 days before expiration | Tech + Raghda + Cheryl (Final Notice) |
| Every day after expiration | Tech + daily summary to Raghda & Cheryl |
